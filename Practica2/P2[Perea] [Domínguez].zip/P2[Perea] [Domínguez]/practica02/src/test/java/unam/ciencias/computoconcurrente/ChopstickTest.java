package unam.ciencias.computoconcurrente;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ChopstickTest {
    static int ROUNDS = 600;
    StringBuffer buffer;
    Chopstick chopstick;
    Thread[] threads;

    @Before
    public void setUp() {
        chopstick = new ChopstickImpl(1);
        buffer =  new StringBuffer();
        threads = new Thread[2];
        threads[0] = new Thread(this::takeAndReleaseChopStick, "0");
        threads[1] = new Thread(this::takeAndReleaseChopStick, "1");
    }

    @Test
    public void testTwoThreads() throws InterruptedException {
        threads[0].start();
        threads[1].start();
        threads[0].join();
        threads[1].join();
        Assert.assertTrue(buffer.toString().matches("^(ab|cd)+$"));
        Assert.assertEquals(2 * ROUNDS, chopstick.getTimesTaken());
    }


    void takeAndReleaseChopStick() {
        for(int i = 0; i < ROUNDS; i++) {
            chopstick.take();
            Thread t = Thread.currentThread();
            buffer.append(t.getName().equals("0") ? 'a' : 'c');
            buffer.append(t.getName().equals("0") ? 'b' : 'd');
            chopstick.release();
        }
    }
}

package unam.ciencias.computoconcurrente;

public class ChopstickImpl implements Chopstick {
    private int id;
    private volatile int timesTaken = 0;
    private volatile SemaphoreImpl semo = new SemaphoreImpl(1);
    
    public ChopstickImpl(int id) {
        this.id = id;
    }

    @Override
    public void take() {
	semo.acquire();
	timesTaken++;
    }

    @Override
    public void release() {
	semo.release();
    }

    @Override
    public int getId() {
        return this.id;
    }


    @Override
    public int getTimesTaken() {
        return timesTaken;
    }
}

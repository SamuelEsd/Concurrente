package unam.ciencias.computoconcurrente;

public class SemaphoreImpl implements Semaphore {
    private int permits;
    private int state;

    public SemaphoreImpl(int permits) {
        this.permits = permits;
	this.state = 0;
    }

    @Override
    public int getPermitsOnCriticalSection() {
        return permits;
    }
    
    @Override
    public void acquire() {
	synchronized(this){
	    try{
		while(state == permits){
		    wait();
		}
		state++;
	    }
	    catch (InterruptedException ie){
		Thread.currentThread().interrupt();
	    }
	}
	
    }
    
    @Override
    public void release() {
	synchronized(this)
	    {
	    try{
		state--;
		notifyAll();
	    }
	    catch(Exception e){
	    	System.out.println("Error en notif yAll del semaphore");
	    	System.out.println(e);
	    }
	}	
    }
}

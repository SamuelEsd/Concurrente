package unam.ciencias.computoconcurrente;

public class PhilosopherWithFilterAlgorithm extends Philosopher {

    private static FilterSemaphoreImpl semi = new FilterSemaphoreImpl(5,4);
    
    public PhilosopherWithFilterAlgorithm() {
        super();
    }

    public void enterTable() throws InterruptedException {
        try {
	    semi.acquire();
            super.enterTable();
        }
        catch (InterruptedException ie) {
            throw ie;
        }
        finally {
	    semi.release();
        }
    }

    @Override
    public void takeChopsticks() {
	leftChopstick.take();
	rightChopstick.take();
    }

    @Override
    public void leaveChopsticks() {
    	leftChopstick.release();
	rightChopstick.release();
    }
}

package unam.ciencias.computoconcurrente;

public class FilterSemaphoreImpl implements Semaphore {

    private int totalThreads;
    private int permits;

    private volatile int[] level;
    private volatile int[] victim;
    public FilterSemaphoreImpl(int totalThreads, int permits) {
        this.totalThreads = totalThreads;
        this.permits = permits;
	level = new int[this.totalThreads];
        victim = new int[this.totalThreads-permits+1];
	for (int i = 1; i < level.length; i++){
	    level[i] = 0;
	}
    }

    @Override
    public int getPermitsOnCriticalSection() {
        return permits;
    }

    private boolean isSomeoneInHigherLevel(int l, int id){
	for(int i = 0; i < level.length; i++){
	    if (level[i] >= l && i != id){
		return true;
	    }
	}
	return false;
    }
    
    @Override
    public void acquire() {
    	int id = Integer.valueOf(Thread.currentThread().getName());
    	for (int i = 1; i < victim.length; i++){
    	    level[id] = i;
    	    victim[i] = id;
    	    while(isSomeoneInHigherLevel(i, id) && victim[i] == id);
    	}
    }

    
    @Override
    public void release() {
	int id = Integer.valueOf(Thread.currentThread().getName());
	level[id] = 0;
    }
}

package unam.ciencias.computoconcurrente;

public class PhilosopherWithSemaphore extends Philosopher {

    private static SemaphoreImpl semo = new SemaphoreImpl(4);
    
    public PhilosopherWithSemaphore() {
        super();
    }

    public void enterTable() throws InterruptedException {
        try {
	    semo.acquire();
            super.enterTable();
        }
        catch (InterruptedException ie) {
            throw ie;
        }
        finally {
	    semo.release();
        }
    }

    @Override
    public void takeChopsticks() {
	leftChopstick.take();
	rightChopstick.take();
    }

    @Override
    public void leaveChopsticks() {
    	leftChopstick.release();
	rightChopstick.release();
    }
}
